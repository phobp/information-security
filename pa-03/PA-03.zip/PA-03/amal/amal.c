/*----------------------------------------------------------------------------
PA-02   Key Exchange using Public-Key Encryption

Written By:  1- Brendan Pho 
             2- Wesley Llamas

             Submitted on: 8/6/2019 
----------------------------------------------------------------------------*/
/*
    I am Amal. I will encrypt a large file to Basim.
    I will exchange the session key with Basim encrypted using his RSA public key.

    Adapted from:
        http://hayageek.com/rsa-encryption-decryption-openssl-c/
*/

#include "../myCrypto.h"

// Always check for possible failures AND Free any dynamic memory you allocated 
// to avoid losing points

void main( int argc , char * argv[] ) 
{    
    RSA  *rsa_privK = NULL  ;
    // key & IV for symmetric encryption of data
    uint8_t  sessionKey[EVP_MAX_KEY_LENGTH] , iv[EVP_MAX_IV_LENGTH] ;    
    char     *plaintextFile  = "bunny.mp4" ;
    int      fd_plain , fd_ctrl , fd_data ;
    
    // Initialize the crypto library
    // ERR_load_crypto_strings ();
    //OpenSSL_add_all_algorithms ();

    // Get AtoB Control and Data file descriptor from the argv[]
    // Open Log File
    // Open Plaintext File
    // Get Basim's RSA Public key generated outside this program by the opessl tool 
    fd_ctrl     = atoi( argv[1] );
    fd_data     = atoi( argv[2] );

    // Generate 512-bit prime number whose primitive root is equal to 2
    BIGNUM *gen ;
    gen = BN_new() ;
    
    // Randomly select a private value 'x' and compute the corresponding public value 'y'

    // Share all previous values with Basim over AtoB control pipe

    FILE *log = fopen("amal/logAmal.txt" , "w"); 
    if (!log) {
        fprintf(stderr, "This is Amal. Could not create log file\n");
        exit(-1);
    }
   
   fd_plain = open(plaintextFile, O_RDONLY);
   if (fd_plain < 0) {
        fprintf(stderr, "This is Amal. Could not open plaintext file.\n");
        exit(1);
   }
    
    uint8_t digest[32];
    rsa_privK = getRSAfromFile("amal/amal_priv_key.pem", 0);
    uint8_t *signature = malloc(RSA_size(rsa_privK));
    
    fprintf(log, "This is Amal. Will send CTRL to FD %d, Data to FD %d\n", fd_ctrl, fd_data);

    // PA03=========================================

    printf("This is Amal. Here are my parameters (in Hex) :");


    BN_CTX *ctx = BN_CTX_new();
    BIGNUM *x = NULL;
    BIGNUM *y = BN_new();
    BIGNUM *r = BN_new();
    BIGNUM *s = BN_new();
 
    const BIGNUM *prime, *qq, *root;

    DH *dh = DH_new();
 
    DH_generate_parameters_ex(dh, 512, 2, NULL);
 
    DH_get0_pqg(dh, &prime, &qq, &root);

    fprintf(log, "    Prime\t : ");
    BN_print_fp(log, prime);
 
    if(BN_is_prime_ex(prime, BN_prime_checks, ctx, NULL))
    {
        fprintf(log, "\n    It is indeed prime");
    }
    else
    {
        fprintf(log, "\n    It is not prime");
        exit(-1);
    }

    fprintf(log, "\n    Root\t : ");
    BN_print_fp(log, root);
 
    // Randomly selects a private value x™ and compute the corresponding public value â€™yâ€™.
    x = BN_myRandom(prime);
 
    // Let y = gen^x mod prime
    BN_mod_exp(y, root, x, prime, ctx);
 
    fprintf(log, "\n    Private value: ");
    BN_print_fp(log, x);
 
    fprintf(log, "\n    Public value : ");
    BN_print_fp(log, y);
 
    fprintf(log, "\n\nAmal: sending prime, root, and public value to Basim\n\n");

    // PA03=========================================

    fprintf(log, "Amal: Starting to digest the data file.\n");
    fflush(log);
    
    size_t digest_size = fileDigest(fd_plain, digest, fd_data);

    FILE* digest_file = fopen("amal/digest.bin","w");
    if (!digest_file) {
        printf("Could not create digest file.\n");
        exit(1);
    }

    fwrite(digest, digest_size, 1, digest_file);
    fclose(digest_file);

    int signature_len = RSA_private_encrypt(digest_size, digest, signature, rsa_privK, RSA_PKCS1_PADDING);

    write(fd_ctrl, signature, signature_len);

    FILE* signature_file = fopen("amal/signature.bin", "w+");
    if (!signature_file) {
        printf("Could not create digest file.\n");
        exit(1);
    }

    fwrite(signature, signature_len, 1, signature_file);
    fclose(signature_file); 
    fflush(log);

    fprintf(log, "\nAmal: Here is my digest of the file:\n");
    BIO_dump_fp(log, digest, digest_size);
    fflush(log);


    // PA03=========================================

    fprintf(log, "\nAmal: Generating the Elgamal Signature\n");


    elgamalSign(digest, 32, prime, root, x, r, s, ctx);
     
    fprintf(log, "\n    r : ");
    BN_print_fp(log, r);
     
    fprintf(log, "\n    s : ");
    BN_print_fp(log, s);
    fprintf(log, "\n");

    BN_write_fd(r, fd_ctrl);
    BN_write_fd(s, fd_ctrl);

    // PA03=========================================

    BIO_dump_fp(log, signature, signature_len);
    fflush(log);

    // Close any open files / descriptors
    fclose(log);
    close(fd_plain);
    close(fd_data);
    close(fd_ctrl);
    free(signature);

    // Clean up the crypto library
    RSA_free( rsa_privK  ) ;
    // ERR_free_strings();
    // RAND_cleanup ();
    // EVP_cleanup ();
    // CONF_modules_free ();
}

